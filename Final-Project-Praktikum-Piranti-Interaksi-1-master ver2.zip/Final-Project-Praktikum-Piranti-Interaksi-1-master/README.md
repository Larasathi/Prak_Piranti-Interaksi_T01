# Final-Project-Praktikum-Piranti-Interaksi-1
Tugas Kuliah 

Ni Made Larasathi P.R.  4210151006

M. Yusuf Prastomo       4210151012

Alat:
- Dualshock PS 4
- MYO Armband

Tema game: 
sebuah game berburu burung yang menggunakan sensor accelerometer, gyroscope, dan vibrate rotor pada dualshock PS 4 sebagai sniper; sedangkan MYO armband berfungsi untuk reload dan pemicu tembakan pada sniper.  
